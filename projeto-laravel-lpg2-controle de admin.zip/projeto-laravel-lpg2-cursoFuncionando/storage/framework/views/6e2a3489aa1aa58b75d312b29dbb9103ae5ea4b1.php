<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Curso
                    <a href="/courses/create" class="float-right btn btn-success">Novo Curso</a>
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <table class="table">
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Ementa</th>
                            <th>Alunos Máximos</th>
                        </tr>
                        
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($c->id); ?></td>
                                <td><?php echo e($c->name); ?></td>
                                <td><?php echo e($c->menu); ?></td>
                                <td><?php echo e($c->amount); ?></td>
                                <td>
                                    <a href="/courses/<?php echo e($c->id); ?>/edit" class="btn btn-warning">Editar</a>

                                    <?php echo Form::open(['url' => "/courses/$c->id", 'method' => 'delete']); ?>

                                        <?php echo e(Form::submit('Deletar', ['class' => 'btn btn-danger'])); ?>

                                    <?php echo Form::close(); ?>


                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>